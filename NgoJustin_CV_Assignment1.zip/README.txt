Justin Ngo, Ju.Q.Ngo@utah.edu
u0453732

--Notes--
for different sets of images, please comment/uncomment the ones in question. 

P.S. It seemed to me project and homework wasn't synonymous in the way you want it turned in. Please let me know how you would like it next time so I can prepare it the way you want. 