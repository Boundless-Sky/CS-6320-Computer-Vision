% Justin Ngo, Normalized Cross Correlation
% function takes in 2 matrix and then returns 0(bad correlation)
% or 1 (best correlation)

function x = NCC( a, b)
    sum_axb = 0; % sum of a times b
    sum_asq = 0; % sum of a squared
    sum_bsq = 0; % sum of b squared
    
    [jth, ith] = size(a); % assume as square matrix
    for j = 1:ith
        for i = 1:jth
            % top portion of equation
            axb = double(a(j,i)*b(j,i));
            sum_axb = sum_axb + axb;
            
            % bottom portion of equation
            a2 = a(j,i)*a(j,i);
            b2 = b(j,i)*b(j,i);
            sum_asq = sum_asq + a2;
            sum_bsq = sum_bsq + b2;
        end
    end
    x = sum_axb/(sqrt(sum_asq)*sqrt(sum_bsq));
    
end
