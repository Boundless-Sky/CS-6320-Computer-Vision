% Justin Ngo
% Computer Vision 6320
% Assignment #1 Jan 19, 2018

% **** PLEASE UNCOMMENT QUESTIONS TO BE LOOKED AT ****

clc; clear; close all;

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%   Problem 1: Detect Line  
%       Take an image and output image with 
%       different color line segments using
%       Canny edge detection and RANSAC.
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% lineDetect_IMG = imread('lineDetect1.bmp');
% lineDetect_IMG = imread('lineDetect2.bmp'); %uncomment as needed
lineDetect_IMG = imread('lineDetect3.bmp');
image(lineDetect_IMG); %display picture, can use imshow
size(lineDetect_IMG);
% Intialize
line_set = {}; % class of line set
line_set_num = 1; %counter to know where to place lineset
iteration = 0;
num_iteration = 10000;
max_pair_distance = 100;
min_pointline_distance = 0.5;
min_line_pixel_num = 50;
blk_white = rgb2gray(lineDetect_IMG);
% extract canny edge pixels from input image I (blk_white1)
canny_edge = edge(blk_white,'canny',0.1);

% loop through to determine edge sets. i.e. the location of the pixel
% where it is 1
[y,x] = size(canny_edge);
n = 1;
for j = 1:y
   for i = 1:x
       if canny_edge(j,i) == 1
          edge_set{n} = [i j]; % save pairs as (x,y)
          n = n + 1;
       end
   end
end

imshow(canny_edge) 

while iteration < num_iteration
    iteration = iteration + 1;
    pick_randP = randi(length(edge_set));
    p = edge_set{pick_randP};
    % distance formula to determine group of pixel within max
    % pair distance and save it.
    m = 1;
    enclosed_edges = [];
    for ii = 1:length(edge_set)
       distance = sqrt((edge_set{ii}(1,1)-p(1,1))^2+...
                       (edge_set{ii}(1,2)-p(1,2))^2);
       if distance <= max_pair_distance
          enclosed_edges{m} = edge_set{ii};
       end
    end
    pick_randQ = randi(length(enclosed_edges));
    q = enclosed_edges{pick_randQ};
    
    % create line equation or just find the line defined by two
    % points and the distance between the line and point in question
    % ax+by+c = 0
    o = 1;
    inlier = [];
    remember = [];
    for w = 1:length(edge_set)
        numerator = abs((q(1,2)-p(1,2))*edge_set{w}(1,1)-(q(1,1)-p(1,1))...
            *edge_set{w}(1,2) + q(1,1)*p(1,2) - q(1,2)*p(1,1));
        denominator = sqrt((q(1,2)-p(1,2))^2 + (q(1,1)-p(1,1))^2);
        pixel_dist = numerator/denominator;
        
        if (pixel_dist >= -min_pointline_distance/2) && (pixel_dist <= ...
                         min_pointline_distance/2)
           inlier{o} = edge_set{w};
           remember(o) = w;
           o = o + 1;
        end
    end
    % add inlier set to line_set if there is sufficently enough pixels
    if length(inlier) >= min_line_pixel_num
        line_set{line_set_num} = inlier;
        line_set_num = line_set_num + 1;
        
        % remove inliers from edge_set
        for oo = o-1:-1:1
           edge_set(remember(oo)) = []; 
        end
        % plot the good lines
        hold on
        plot([p(1),q(1)],[p(2),q(2)],'LineWidth',2,'color',rand(1,3));
        hold off
    else
        continue
    end
end

% % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% %   Problem 2: Sky Segmentation
% %       Using 6 thresholds, define the Upper
% %       and lower bounds of the 3 RGB componets
% %       of a picture to determine sky or not.
% % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% 
% % Take in original image
% input_IMG = imread('detectSky1.bmp');
% % input_IMG = imread('detectSky2.bmp');
% % input_IMG = imread('detectSky3.bmp');
% 
% % color range thresholds
% r_min = 0;
% r_max = 100;
% g_min = 0;
% g_max = 150;
% b_min = 100;
% b_max = 255;
% 
% % create blank image and find size of original image
% output_IMG = zeros(size(input_IMG));
% [row, column, ~] = size(input_IMG);
% 
% % iterate between every pixel in the R, G and B space
% % and compare to threshold. If within threshold then
% % consider white (255,255,255) otherwise black(0,0,0)
% 
% for j = 1:row
%     for i = 1:column
%        flagR = 0;
%        flagG = 0;
%        flagB = 0;
%        for rgb_space = 1:3
%            if rgb_space == 1 %red
%                if (input_IMG(j,i,rgb_space) >= r_min) && ...
%                   (input_IMG(j,i,rgb_space) <= r_max)
%                    flagR = 1;
%                end
%            end
%            if rgb_space == 2 %green
%                if (input_IMG(j,i,rgb_space) >= g_min) && ...
%                   (input_IMG(j,i,rgb_space) <= g_max)
%                    flagG = 1;
%                end 
%            end
%            if rgb_space == 3 %blue
%                if (input_IMG(j,i,rgb_space) >= b_min) && ...
%                   (input_IMG(j,i,rgb_space) <= b_max)
%                    flagB = 1;
%                end
%            end
%        end
%        if (flagR == 1) && (flagG ==1) && (flagB == 1)
%            output_IMG(j,i,:) = 255;
%        else
%            output_IMG(j,i,:) = 0;
%        end
%     end
% end
% 
% imshow(output_IMG)

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%   Problem 3: Simple Stereo Matching program
%       Using 6 thresholds, define the Upper
%       and lower bounds of the 3 RGB componets
%       of a picture to determine sky or not.
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% % take in left and right image
% left_IMG = imread('left1.png'); 
% right_IMG = imread('right1.png');
% % left_IMG = imread('left2.png'); 
% % right_IMG = imread('right2.png');
% % left_IMG = imread('left3.bmp'); 
% % right_IMG = imread('right3.bmp');
% 
% disparity_range = 50; % x' (right pixel) = x(left pixel) - d
% window_size =5; % search window size around p(x,y) left image Matrix A
% extend = (window_size - 1)/2; % compute "extension" size to be around pixel
% % get dimension of image (assuming left and right are the same size)
% % assumes images are rectified (meaning on same plane)
% [Ny,Nx,~] = size(right_IMG);
% 
% % intialize matrix
% disparity_img = zeros(Ny,Nx);
% % convert the 2 images to grayscale image
% left_gray = double(rgb2gray(left_IMG));
% right_gray = double(rgb2gray(right_IMG));
% % disparity image (white large disparity, meaning it moved lots, depth and 
% % disparity is inversely proprtional. black is less movement)
% % iterate between each pixel except edges/boundaries
% for y = 1+extend:Ny-extend
%     for x = 1+extend:Nx-extend
%        bestDisparity = 0; %meaning the pixel on left corresponds to the right
%        bestNCC = 0; %keep track of best NCC. 1 = match, 0 = none
%        
%        % run through the and check the length of the disparity
%        for disparity_cnt = 1:disparity_range
%            Lpatch = left_gray(y-extend:y+extend,x-extend:x+extend);
%            if x-disparity_cnt-extend <= 0
%               break
%            else
%                
%            Rpatch = right_gray(y-extend:y+extend,...
%                     x-disparity_cnt-extend:x-disparity_cnt+extend);
%            currentNCC = NCC(Lpatch,Rpatch);
%            if(currentNCC > bestNCC)
%               bestNCC = currentNCC;
%               bestDisparity = disparity_cnt;
%            end
%            end
%        end
%        disparity_img(y,x) = bestDisparity;
%     end
% end
% % image only shows from 0 to 1. Thus use mat2gray to 
% % convert values to 0 to 1 and then display
% % imshow(mat2gray(disparity_img))
% imshow(disparity_img,[1 50]) % this method works as well