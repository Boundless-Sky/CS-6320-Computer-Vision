% Justin Ngo
%  Assignment 3 - BELIEF PROPAGATION (BP)


% Problem 1 - Factor Graph / Cost Table ~ Hamming Code
% factor graph for the N = 7, k = 4 Hamming Code which has seven codeword
% bits. 4 left most are the information bits and the last 3 are partiy bits

clear, clc, close all

% Step 1: Messages from VARIABLE nodes to FACTOR nodes are intially random
%           or non-informative values. 

% cost tables
c1 = [0.0 3.0];
c2 = [0.0 2.0];
c3 = [0.0 2.5];
c4 = [0.0 5.4];
c5 = [0.0 4.0];
c6 = [0.2 0.0];
c7 = [0.7 0.0];

% messages , beliefs
m1 = [0 0]; b1 = [0 0];
m2 = [0 0]; b2 = [0 0];
m3 = [0 0]; b3 = [0 0];
m4 = [0 0]; b4 = [0 0];
m5 = [0 0]; b5 = [0 0];
m6 = [0 0]; b6 = [0 0];
m7 = [0 0]; b7 = [0 0];

% partiy messages
m1toa = [0 0]; 
m1tob = [0 0]; 
m1toc = [0 0]; 

m2toa = [0 0]; 
m2tob = [0 0]; 

m3toa = [0 0]; 
m3toc = [0 0]; 

m4tob = [0 0]; 
m4toc = [0 0]; 

m5toa = [0 0]; 

m6tob = [0 0]; 

m7toc = [0 0]; 

i = 0;
oldstate = [ 0 0 0 0 0 0 0 ];
newstate = [ 0 0 0 0 0 0 0 ];
while (i ~= 10) 

    
    % Step 2: FACTOR nodes compute from the incoming messages new outgoing
    %           messages
    for k = 1:2
        % variable 1
        msg1(k) = c1(k);
        msg1a(k) = parity(k, m2toa, m3toa, m5toa);
        msg1b(k) = parity(k, m2tob, m4tob, m6tob);
        msg1c(k) = parity(k, m3toc, m4toc, m7toc);
        
        % variable 2
        msg2(k) = c2(k);
        msg2a(k) = parity(k, m1toa, m3toa, m5toa);
        msg2b(k) = parity(k, m1tob, m4tob, m6tob);
      
        % variable 3
        msg3(k) = c3(k);
        msg3a(k) = parity(k, m1toa, m2toa, m5toa);
        msg3c(k) = parity(k, m1toc, m4toc, m7toc);
      
        % variable 4
        msg4(k) = c4(k);
        msg4b(k) = parity(k, m1tob, m2tob, m6tob);
        msg4c(k) = parity(k, m1toc, m3toc, m7toc);
       
        % variable 5
        msg5(k) = c5(k);
        msg5a(k) = parity(k, m1toa, m2toa, m3toa);
  
        % variable 6
        msg6(k) = c6(k); 
        msg6b(k) = parity(k, m1tob, m2tob, m4tob);
        
        % variable 7
        msg7(k) = c7(k);
        msg7c(k) = parity(k, m1toc, m3toc, m4toc);
        
        
        % Step 3: The messages are converted into beliefs, which in BP are
        %           generally represented as a cost for each possible state
        b1(k) = msg1(k) + msg1a(k) + msg1b(k) + msg1c(k);
        b2(k) = msg2(k) + msg2a(k) + msg2b(k);
        b3(k) = msg3(k) + msg3a(k) + msg3c(k);
        b4(k) = msg4(k) + msg4b(k) + msg4c(k);
        b5(k) = msg5(k) + msg5a(k);
        b6(k) = msg6(k) + msg6b(k);
        b7(k) = msg7(k) + msg7c(k);
    end
    
    % Step 4: The beliefs are thresholded to their lowest cost (represented
    %         by the number inside the variable node), and a termination is
    %         checked
    [ energy1 , minb1] = min(b1);
    [ energy2 , minb2] = min(b2);
    [ energy3 , minb3] = min(b3);
    [ energy4 , minb4] = min(b4);
    [ energy5 , minb5] = min(b5);
    [ energy6 , minb6] = min(b6);
    [ energy7 , minb7] = min(b7);
    
    newstate = [(minb1 - 1) (minb2 - 1) (minb3 - 1) (minb4 - 1) ... 
        (minb5 - 1) (minb6 - 1) (minb7 - 1) ];
    
    if i == 0
       oldstate = newstate;
    else
        codeword_flag = 0;
        for checkbit = 1:7
            if newstate(checkbit) == oldstate(checkbit)
                codeword_flag  = codeword_flag + 1;
            end
        end
        if codeword_flag == 7
            disp('codeword is:');
            disp(newstate);
            disp('energy of bits repsectively:');
            fprintf('%0.2f, %0.2f, %0.2f, %0.2f, %0.2f, %0.2f, %0.2f\n', ...
                energy1, energy2, ...
                energy3, energy4, energy5, energy6, energy7);
            disp('Total energy: ');
            disp(energy1 + energy2 + energy3 + energy4 + energy5 + energy6 ...
                + energy7);
            break;
        else
            oldstate = newstate;
        end
    end
    
    
  
    
    % Step 5: The beliefs and incoming messages are used to compute new
    %           outgoing messages from the variable nodes, and then one
    %           returns to step 2, and the cycle continues.
    
    m1 = b1 - msg1;
    m2 = b2 - msg2;
    m3 = b3 - msg3;
    m4 = b4 - msg4;
    m5 = b5 - msg5;
    m6 = b6 - msg6;
    m7 = b7 - msg7;
    
    m1toa = b1 - msg1a; 
    m1tob = b1 - msg1b; 
    m1toc = b1 - msg1c; 

    m2toa = b2 - msg2a; 
    m2tob = b2 - msg2b;  

    m3toa = b3 - msg3a; 
    m3toc = b3 - msg3c; 

    m4tob = b4 - msg4b; 
    m4toc = b4 - msg4c;  

    m5toa = b5 - msg5a;

    m6tob = b6 - msg6b;

    m7toc = b7 - msg7c;
    i = i + 1;
end








