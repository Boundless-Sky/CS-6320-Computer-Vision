% Justin Ngo
% parity checks
% state = 1 or 2 (corresponds to 0 and 1 but we use 1 and 2 so we can do
% arrays for matlab. 

% if you are looking for message from parity to i.e x1 (variable node 1)
% then the input is everything else besides x1 and the state of x1

% m1...m4 = 1 by 2 messages to the parity node (factor node)
% vector_cost = 1 by 2 cost table
function minparity_cost = parity(state, m1, m2, m3)
                                
    % build table that stores the states and their associated message cost
    minparity_cost = 999999;
    for a = 1:2
        for b = 1:2
            for c = 1:2
                paritycheck = (state-1) + (a-1) + (b-1) + (c-1);
                if mod(paritycheck,2) == 0 %even 
                    paritycost = 0;
                else
                    paritycost = 1000; % or infinity
                end
                
                newminparity_cost = paritycost + m1(a) + m2(b) + m3(c);
                
                if newminparity_cost < minparity_cost
                    minparity_cost = newminparity_cost;
                end
            end
        end
    end
    
    
end