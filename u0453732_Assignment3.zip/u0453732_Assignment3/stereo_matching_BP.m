% Justin Ngo
% Assignment 3 Problem 2 - Stero Matching program 
%   Stereo matching that comuptes the dispartiy map using belief
%   propagation
% http://nghiaho.com/?page_id=1366 -> help to understand
clear, clc, close all
% take in left (reference) and right image
imageset = 3;
switch imageset
    case 1
        left_IMG = imread('left1.png'); 
        right_IMG = imread('right1.png');
    case 2
        left_IMG = imread('left2.png'); 
        right_IMG = imread('right2.png');
    case 3
        left_IMG = imread('left3.bmp'); 
        right_IMG = imread('right3.bmp');
    otherwise
        left_IMG = imread('left1.png'); 
        right_IMG = imread('right1.png');
end

d = 50; % disparity -> x' (right pixel) = x(left pixel) - d
lambda = [1 10 50 100];
left_gray = double(rgb2gray(left_IMG));
right_gray = double(rgb2gray(right_IMG));

[M,N] = size(left_gray); 
pairwise_num = (M-1)*N + (N-1)*M;
disparity_image = zeros(M,N); % this stores my belief. 
belief(1:M, 1:N, 1:d) = 0;


% if ~exist('msg2var.mat')
%     progressbar('msg2var');
%     for p = 1:M
%         for q = 1:N
%             for r = 1:d
%                 msg2var(p,q,r).left = 0;
%                 msg2var(p,q,r).right = 0;
%                 msg2var(p,q,r).up = 0;
%                 msg2var(p,q,r).down = 0;
%             end
%         end
% %         progressbar(p/M);
%     end
%     save('msg2var.mat' ,'msg2var', '-v7.3');
%     progressbar(1);
% else
%     load('msg2var.mat','msg2var');
% end
msg2var = zeros(M,N,d,4);
msgfrmfac = zeros(M,N,d,4);
% if ~exist('msgfrmfac.mat')
%     progressbar('msgfrmfac');
%     for p = 1:M
%         for q = 1:N
%             for r = 1:d
%                 msgfrmfac(p,q,r).left = 0;
%                 msgfrmfac(p,q,r).right = 0;
%                 msgfrmfac(p,q,r).up = 0;
%                 msgfrmfac(p,q,r).down = 0;
%             end
%         end
% %         progressbar(p/M);
%     end
%     save('msgfrmfac.mat','msgfrmfac', '-v7.3');
%     progressbar(1);
% else
%     load('msgfrmfac.mat','msgfrmfac');
% end
% don't store pairwise factor nodes (potts) 

% M is height
% N is width 
% MN unary factor nodes 
% (N-1)M + (M-1)N pairwise factor nodes

% Markov Random Field
% we want to minimize E(d) = E_data(d) = lambda*E_smooth(d)
% where E_smooth is the potts model


% for nlambda = 1:length(lambda)
%     potts = lambda*potts;
% end

progressbar('StereoMatch BP', 'factor to variable nodes', ...
    'belief', 'message update to factor' );
% wait = waitbar(0, 'Please wait...');

g = 1; %lambda index
i = 0;
niter = 20;
while i ~= niter
%     if ~exist('unary_cost.mat')
        for j = 1:M % row (y)
            for k = 1:N %column (x)
                for L = 1:d %disparity 1 to 50
                    if (k - L) <= 0
                        unary_cost(j,k,L) = 0;
                    else
                        unary_cost(j,k,L) = abs(left_gray(j,k) - ...
                            right_gray(j,k-L));
                    end
                end
            end
        end
%         save('unary_cost.mat', 'unary_cost');
%     else
%         load('unary_cost.mat', 'unary_cost');
%     end

    %factor nodes back to variable nodes
    for x = 2:N-1
        for y = 2:M-1
            for z = 1:d
%                 msg2var(y,x,z).left = unary_cost(y,x-1,z) + potts(z, belief(y,x-1,z), lambda(g)) + msgfrmfac(y,x,z).left;
%                 msg2var(y,x,z).right = unary_cost(y,x+1,z) + potts(z, belief(y,x+1,z), lambda(g)) + msgfrmfac(y,x,z).right;
%                 msg2var(y,x,z).up =  unary_cost(y-1,x,z) + potts(z, belief(y-1,x,z), lambda(g)) + msgfrmfac(y,x,z).up;
%                 msg2var(y,x,z).down =  unary_cost(y+1,x,z) + potts(z, belief(y+1,x,z), lambda(g)) + msgfrmfac(y,x,z).down;
                msg2var(y,x,z,1) = unary_cost(y,x-1,z) + potts(z, disparity_image(y,x-1), lambda(g)) + msgfrmfac(y,x+1,z,2) + msgfrmfac(y-1,x,z,3) + msgfrmfac(y+1,x,z,4);
                msg2var(y,x,z,2) = unary_cost(y,x+1,z) + potts(z, disparity_image(y,x+1), lambda(g)) + msgfrmfac(y,x-1,z,1) + msgfrmfac(y-1,x,z,3) + msgfrmfac(y+1,x,z,4); 
                msg2var(y,x,z,3) = unary_cost(y-1,x,z) + potts(z, disparity_image(y-1,x), lambda(g)) + msgfrmfac(y,x-1,z,1) + msgfrmfac(y,x+1,z,2) + msgfrmfac(y+1,x,z,4);
                msg2var(y,x,z,4) = unary_cost(y+1,x,z) + potts(z, disparity_image(y+1,x), lambda(g)) + msgfrmfac(y,x-1,z,1) + msgfrmfac(y,x+1,z,2) + msgfrmfac(y-1,x,z,3);
            end
        end
        progressbar([],x/(N-1),[], []);
    end
    % go through every single pixel not on the boundary and compute
    % the energy function iterating over the disparity range. for the 
    % smoothing function if we say d = 1, we will keep the row at 1 and 
    % check which disparity on the column match. 

    % we will ignore the border for simplicity
    totalenergy = 0;
    for x = 2:N - 1
        for y = 2:M - 1
            for z = 1:d
%                 belief(y,x,z) = unary_cost(y,x,z) + msg2var(y,x,z).left + msg2var(y,x,z).right + msg2var(y,x,z).up + msg2var(y,x,z).down;
                belief(y,x,z) =  msg2var(y,x,z,1) + msg2var(y,x,z,2) + msg2var(y,x,z,3) + msg2var(y,x,z,4);
            end
            [minenergy, disparity] = min(belief(y,x,:)); 
            disparity_image(y,x) = disparity;
            totalenergy = totalenergy + minenergy;
        end
        progressbar([],[],(x/(N-1)),[]);
    end

    % update the messages to be sent back to factor nodes
     for x = 2:N-1
        for y = 2:M-1
            for z = 1:d
%                 msgfrmfac(y,x,z).left = belief(y,x,z) -  msg2var(y,x,z).left ;
%                 msgfrmfac(y,x,z).right = belief(y,x,z) -  msg2var(y,x,z).right ;
%                 msgfrmfac(y,x,z).up = belief(y,x,z) -  msg2var(y,x,z).up ;
%                 msgfrmfac(y,x,z).down = belief(y,x,z) -  msg2var(y,x,z).down ;
                msgfrmfac(y,x,z,1) = belief(y,x,z) - msg2var(y,x,z,1);
                msgfrmfac(y,x,z,2) = belief(y,x,z) - msg2var(y,x,z,2);
                msgfrmfac(y,x,z,3) = belief(y,x,z) - msg2var(y,x,z,3);
                msgfrmfac(y,x,z,4) = belief(y,x,z) - msg2var(y,x,z,4);
            end
        end
        progressbar([],[],[],(x/(N-1)));
    end

    % termination condition -> states are all the same
    if i == 0
        oldstate = disparity_image; 
    else
        for x = 1:N
            for y = 1:M
                if oldstate(y,x) ~= disparity_image(y,x)
                    continue;
                elseif oldstate(M,N) == disparity_image(M,N)
                    break;
                end
            end
        end
    end

    % update belief and update the state space (disparity image)
    % send new messages and repeat unti terminal condition
    progressbar(i/niter,[],[],[]);
    %waitbar(i/19, wait);
    i = i + 1;
end
progressbar(1); %close progress bar
imshow(disparity_image,[1 d]);
title(['Image Set:', num2str(imageset), ' Lambda:',num2str(lambda(g))])
fprintf('Final Cost Function Value %0.2E\n', minenergy); 
fprintf('Total Energy: %0.2E for lambda %d\n', totalenergy, lambda(g));


