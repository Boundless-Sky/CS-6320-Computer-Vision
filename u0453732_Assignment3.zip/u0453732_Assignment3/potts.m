% Justin Ngo
% Potts Model
% assignment 3 part 2 - stereo matching belief propagation
function n = potts(x , y, lambda)
    if x == y
        n = 0;
    else
        n = lambda;
    end
end